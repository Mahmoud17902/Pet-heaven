import 'package:flutter/material.dart';
class MyTitle extends StatelessWidget {
  const MyTitle({
    super.key,
    required this.title,
    required this.fontSize,
  });

  final String title;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    return Text(title,style: TextStyle(color: Colors.black54,fontSize: 40),);
  }
}