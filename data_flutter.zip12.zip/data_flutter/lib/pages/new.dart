import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'homePage.dart';

class newWid extends StatefulWidget {
  const newWid({super.key});

  @override
  State<newWid> createState() => _newWidState();
}

class _newWidState extends State<newWid> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:SafeArea(
          child: Center(
            child: Column(
              children: [
                SizedBox(height: 90,),
                Image.asset("images/book.png",height: 200,),
                Text("No bookings yet",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                SizedBox(height: 5,),
                Text("when you place your first book, it will appear here."),
                SizedBox(height: 180,),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFFC3BDA5),
                  ),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => HomePage(), ),);
                  },
                  child:
                  Text("       Book now        ", style:GoogleFonts.robotoCondensed
                    (fontSize: 20,height: 3,color: Colors.black),),
                ),
              ],
            ),
          )
      ),
    );
  }
}
