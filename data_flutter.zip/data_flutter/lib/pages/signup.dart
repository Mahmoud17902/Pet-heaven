import 'package:data_flutter/pages/homePage.dart';
import 'package:data_flutter/pages/loginscreen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
class signup extends StatefulWidget {
  const signup({super.key});

  @override
  State<signup> createState() => _signupState();
}

class _signupState extends State<signup> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      body: SafeArea(
          child: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text("Sign up", style: GoogleFonts.robotoCondensed(
            fontSize: 50, fontWeight: FontWeight.bold,color: Colors.brown),),
    SizedBox(height: 5,),
    Padding(
    padding: const EdgeInsets.symmetric(horizontal: 40),
    child: Container(
    decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(20)
    ),
    child: Padding(
    padding: const EdgeInsets.symmetric(horizontal: 15),
    child: TextField(
    decoration: InputDecoration(
    border: InputBorder.none,
    hintText: "Name",
    ),),),),),
    SizedBox(height: 20,),
    Padding(
    padding: const EdgeInsets.symmetric(horizontal: 40),
    child: Container(
    decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(20)
    ),
    child: Padding(
    padding: const EdgeInsets.symmetric(horizontal: 15),
    child: TextField(
    decoration: InputDecoration(
    border: InputBorder.none,
    hintText: "Email",
    ),),),),),
    SizedBox(height: 20,),
    Padding(
    padding: const EdgeInsets.symmetric(horizontal: 40),
    child: Container(
    decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(20)
    ),
    child: Padding(
    padding: const EdgeInsets.symmetric(horizontal: 15),
    child: TextField(
    decoration: InputDecoration(
    border: InputBorder.none,
    hintText: "Phone number",
    ),),),),),
          SizedBox(height: 20,),
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)
                  ),
                  child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: TextField(
                        obscureText: true,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "Password",
                          ))))),
          SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20)
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child: TextField(
                  obscureText: true,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Confirm Password",
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 20,),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40,),
                child: GestureDetector(
                  child:
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFFC3BDA5),
                    ),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => loginscreen(), ),);
                    },
                    child:
                    Text("Sign up",style:GoogleFonts.robotoCondensed(fontSize: 20,height: 3,color: Colors.black),),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 10,),
          Center(child: Text("or with", style: GoogleFonts.robotoCondensed(fontSize: 30,),)),
          SizedBox(height: 10,),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40,),
                child: GestureDetector(
                  child:
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.indigoAccent,
                    ),
                    onPressed: () {

                    },
                    child:
                        Row(
                          children: [
                            Icon(Icons.facebook_sharp),
                    SizedBox(width: 90,),
                    Text("Signup With Facebook",style:GoogleFonts.robotoCondensed(fontSize: 20,height: 3,color: Colors.black),),
                  ]
                  ),
                        ),
                ),
              ),
            ],
          ),
          SizedBox(height: 10,),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40,),
                child: GestureDetector(
                  child:
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                    ),
                    onPressed: () {

                    },
                    child:
                        Row(
                    children: [
                      Icon(Icons.attach_email_outlined),
                  SizedBox(width: 90,),
                    Text("Signup With Gmail",style:GoogleFonts.robotoCondensed(fontSize: 20,height: 3,color: Colors.black),),
                  ]
                  ),
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Already have an account?",
                    style: GoogleFonts.robotoCondensed(
                        fontWeight: FontWeight.bold),),
                  SizedBox(width: 10,),
                  TextButton(
                    style: ElevatedButton.styleFrom(
                    ),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => loginscreen(), ),);
                    },
                    child:
                    Text("Login",style:GoogleFonts.robotoCondensed(fontSize: 20,height: 3),),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
          )
      ),
    );
  }
}
