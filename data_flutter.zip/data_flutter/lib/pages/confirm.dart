import 'package:data_flutter/pages/homePage.dart';
import 'package:data_flutter/pages/loginscreen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
class confirm extends StatefulWidget {
  const confirm({super.key});

  @override
  State<confirm> createState() => _confirmState();
}

class _confirmState extends State<confirm> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:SafeArea(
          child: Center(
            child: Column(
              children: [
                Image.asset("images/WhatsApp Image 2024-12-27 at 9.15.33 PM.jpeg",height: 666,width: 90000,fit: BoxFit.fitWidth,),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 1),
                      child: GestureDetector(
                        child:
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.greenAccent,  
                          ),
                          onPressed: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (context) => loginscreen(), ),);
                          },
                          child:
                          Text("          Login          ", style:GoogleFonts.robotoCondensed
                            (fontSize: 20,height: 3,color: Colors.black87),),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          )
      ),
    );
  }
}