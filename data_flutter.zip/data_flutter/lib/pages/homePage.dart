import 'package:data_flutter/pages/loginscreen.dart';
import 'package:data_flutter/widget/myTitle.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:data_flutter/pages/homePage.dart';

import 'new.dart';
class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  bool _obscureText = true;

  final TextEditingController _controller = TextEditingController();

  final List<Widget> _pages = [
    HomeContent(),
   Scaffold(
  body:SafeArea(
    child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
    SizedBox(height: 20),
    Padding(
      padding: const EdgeInsets.all(15.0),
      child: Container(
        height: 45,
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.black26),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            decoration: InputDecoration(
              hintText: "Search for ....",
              prefixIcon: Icon(Icons.search, color: Colors.black26, size: 30),
              focusedBorder: InputBorder.none,
              disabledBorder: InputBorder.none,
              enabledBorder: InputBorder.none,
              errorBorder: InputBorder.none,
            ),
          ),
        )
      ),
    ),
          SizedBox(height: 20,),
          Text("   Popular cities",style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold),),
          SizedBox(height: 20,),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                NewWidget(imagePath: 'images/download.jpeg', title: "Pet care"),
                SizedBox(width: 50),
                NewWidget(imagePath: 'images/download.jpeg', title: "Pet care"),
                SizedBox(width: 50),
                NewWidget(imagePath: 'images/download.jpeg', title: "Pet care"),
              ],
            ),
          ),
          SizedBox(height: 20,),
          Text("   Recent searches",style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold),),
    ],
  ),
  ),
   ),

    newWid(),
    Scaffold(
      body:SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Container(
                  height: 45,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: Colors.black26),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: ListView(
                      itemExtent: 7,
                    )
                  )
              ),
            ),
            SizedBox(height: 20,),
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)
                    ),
                    child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 15),
                        child:
                        TextField(
                            obscureText: true,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: "Password",

                            ))))),
          ],
        ),
      ),
    ),
  ];
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFC3BDA5),
        iconTheme: IconThemeData(),
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: _pages[_selectedIndex],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: const Icon(Icons.home, color: Colors.black87), label: 'Home', backgroundColor: Color(0xFFC3BDA5),),
          BottomNavigationBarItem(
            icon: const Icon(Icons.search, color: Colors.black87), label: 'Search', backgroundColor: Color(0xFFC3BDA5), ),
          BottomNavigationBarItem(
            icon: const Icon(Icons.menu_book_outlined, color: Colors.black87),label: 'Booking', backgroundColor: Color(0xFFC3BDA5)),
          BottomNavigationBarItem(
            icon: const Icon(Icons.person, color: Colors.black87),label: 'Profile', backgroundColor: Color(0xFFC3BDA5)),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        unselectedItemColor: Colors.black,
        selectedItemColor: Colors.black,
      ),
    );
  }
}
//////////////////////////////////////////
// ///////////////////////////////////////  
class HomeContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 20,left: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            alignment: Alignment.center,
            child: Image.asset('images/Screenshot 2025-02-03 235020.jpeg', fit: BoxFit.fitWidth,),
          ),
          SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                NewWidget(imagePath: 'images/download.jpeg', title: "Hosting"),
                SizedBox(width: 50),
                NewWidget(imagePath: 'images/download.jpeg', title: "Pet care"),
                SizedBox(width: 50),
                NewWidget(imagePath: 'images/download.jpeg', title: "Traning"),
                SizedBox(width: 50),
                NewWidget(imagePath: 'images/download.jpeg', title: "Additional services"),
              ],
            ),
          ),
          SizedBox(height: 10,),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  foregroundColor: Colors.transparent,
                  shadowColor: Colors.transparent
                ),
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => HomePage(), ),);
                },
                child:
                Image.asset("images/home.png",width: 400,height: 300,),
              ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      elevation: 0,
                      foregroundColor: Colors.transparent,
                      shadowColor: Colors.transparent
                  ),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => HomePage(), ),);
                  },
                  child:
                  Image.asset("images/home.png",width: 400,height: 300,),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      elevation: 0,
                      foregroundColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                  ),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => HomePage(), ),);
                  },
                  child:
                  Image.asset("images/home.png",width: 400,height: 300,),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

Widget popularFoodCard() {
  return Card(
    child: Column(
      children: [
        Container(
          height: 100,
          width: 200,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            image: DecorationImage(
              image: NetworkImage("images/home.png",),
              fit: BoxFit.cover,
            ),
          ),
        ),
      ],
    ),
  );
}
class NewWidget extends StatelessWidget {
  final String imagePath;
  final String title;

  NewWidget({required this.imagePath, required this.title});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Image.asset(
          imagePath,
          width: 50,
          height: 50,
        ),
        SizedBox(height: 8),
        Text(title),
      ],
    );
  }
}


