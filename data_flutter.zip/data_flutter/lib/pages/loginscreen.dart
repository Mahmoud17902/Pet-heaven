import 'package:data_flutter/pages/Changepassword.dart';
import 'package:data_flutter/pages/facebook.dart';
import 'package:data_flutter/pages/gmail.dart';
import 'package:data_flutter/pages/homePage.dart';
import 'package:data_flutter/pages/signup.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
class loginscreen extends StatefulWidget {
  const loginscreen({super.key});

  @override
  State<loginscreen> createState() => _loginscreenState();
}

class _loginscreenState extends State<loginscreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(height: 40,),
              Row(
                children: [
                  SizedBox(width: 40,),
                  Row(
                    children: [
                      Text("Hi,Welcome Back!", style: GoogleFonts.robotoCondensed(
                        fontSize: 50, fontWeight: FontWeight.bold,color: Colors.brown )
                        ,),
                      Image.asset("images/hand.png")
                    ],
                  ),
                ],
              ),
              SizedBox(height: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text("                E-mail ",style: GoogleFonts.robotoCondensed(
                    fontWeight: FontWeight.bold,
                  )),
                ],
              ),
              Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: Container(
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20)
                      ),
                      child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child:
                          TextField(
                              obscureText: true,
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: "example@gmail.com",
                              ))))),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text("                Password",style: GoogleFonts.robotoCondensed(fontWeight: FontWeight.bold)
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: TextField(
                      obscureText: true,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: "Enter your password",
                      ),
                    ),
                  ),
                ),
              ),
              Row(
                children: [
                  SizedBox(width: 260,),
                  TextButton(
                    style: ElevatedButton.styleFrom(
                    ),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => Changepassword(), ),);
                    },
                    child:
                    Text("Forget the password?",style:GoogleFonts.robotoCondensed(fontSize: 20,height: 3,color: Colors.green),),
                  ),
                ],
              ),
              SizedBox(height: 15,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40,),
                    child: GestureDetector(
                        child:
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFFC3BDA5),
                          ),
                          onPressed: () {
                            Navigator.of(context).push(
                                MaterialPageRoute(builder: (context) => HomePage(), ),);
                          },
                          child:
                        Text("Log in",style:GoogleFonts.robotoCondensed(fontSize: 20,height: 3,color: Colors.black87),),
                        ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20,),
              Center(child: Text("Or with", style: GoogleFonts.robotoCondensed(fontSize: 30,),)),
              SizedBox(height: 20,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40,),
                    child: GestureDetector(
                      child:
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.indigoAccent,
                        ),
                        onPressed: () {

                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => facebook(), ),);
                        },
                        child:
                            Row(
                              children: [
                                Icon(Icons.facebook_sharp),
                                SizedBox(width: 90,),
                                Text("Login With Facebook",style:GoogleFonts.robotoCondensed(fontSize: 20,height: 3,color: Colors.black),),
                              ],
                            )
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40,),
                    child: GestureDetector(
                      child:
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                        ),
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => gmail(), ),);
                        },
                        child:
                          Row(
                          children: [
                          Icon(Icons.attach_email_sharp),
                      SizedBox(width: 90,),
                      Text("Login With Gmail",style:GoogleFonts.robotoCondensed(fontSize: 20,height: 3,color: Colors.black87),),
                      ],
                    )
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Don't have an account?",
                    style: GoogleFonts.robotoCondensed(
                        fontWeight: FontWeight.bold),),
                  SizedBox(width: 10,),
                  TextButton(
                    style: ElevatedButton.styleFrom(
                    ),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => signup( ), ),);
                    },
                    child:
                    Text("Sign up",style:GoogleFonts.robotoCondensed(fontSize: 20,height: 3),),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}