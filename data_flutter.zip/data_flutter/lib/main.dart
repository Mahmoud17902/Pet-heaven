import 'package:data_flutter/pages/homePage.dart';
import 'package:data_flutter/pages/loginscreen.dart';
import 'package:data_flutter/pages/signup.dart';
import 'package:flutter/material.dart';

void main()  {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pet heaven',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home:  loginscreen(),
    );
  }
}
